trackme = {
    '10.220.249.232': ["mrjones"],
}
ssh_user = 'timekpr-next-remote'
ssh_password = 'timekpr-next-remote'
ssh_timekpra_bin = '/usr/bin/timekpra'
ssh_key = './id_timekpr'
